package com.example.ex4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex4ApplicationTests {

	@Test
	void contextLoads() {
	}

}

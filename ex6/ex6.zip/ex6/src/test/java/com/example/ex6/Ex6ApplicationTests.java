package com.example.ex6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex6ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.ex7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
